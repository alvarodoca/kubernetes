</main>
        <footer>
            <address>
                <p>9335 Harris Corners Parkway</p>
                <p>Suite 500</p>
                <p>Charlotte, North Carolina 28269</p>
                <p>info@f1experiences.com</p>
                <p>+34 900 838 030</p>
            </address>
            <div>Copyright 2024 Todos los derechos reservados</div>
            <section class="social">
                <a href="https://www.facebook.com/Formula1"><img src="./img/facebook.png"></a>
                <a href="https://www.instagram.com/f1/"><img src="./img/instagram.png"></a>
                <a href="https://x.com/F1?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor"><img src="./img/twitter.jpg"></a>
            </section>
        </footer>
    </div>

</body>
</html>