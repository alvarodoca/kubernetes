<?php
    include "header.php";
?>
<br><br><br>
<div class="imagen_inicio">
    <center><img src="img/F1.png" width="950px"></center>
</div>

<?php
    include "footer.php";
?>