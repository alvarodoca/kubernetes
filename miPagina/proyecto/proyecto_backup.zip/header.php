<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilos.css">
    <title>Gestion de productos</title>
</head>
<body>
    <div class=contenedor>
        <div class="principal">
            <div class=op><a href="index.php">Inicio</a></div>
            <div class=op><a href="alta.php">¡Hazte Socio!</a></div>
            <div class=op><a href="escuderias.php">Escuderias</a></div>
            <div class=op><a href="clasificacion.php">Clasificación</a></div>
            <div class=op><a href="login.php">Login</a></div>
        </div>


    <main>