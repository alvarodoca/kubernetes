<!--Incluimos nuestro cabecero genérico para todos-->
<?php
    include "header.php";
?>
<div class="altas">
    
    <?php
    
// Recibimos los datos enviados por el formulario
        $escuderia = $_POST["escuderia"];
        $coche=$_POST["coche"];
        $color=$_POST["color"];
        $piloto1=$_POST["piloto1"];
        $piloto2=$_POST["piloto2"];
        $director=$_POST["director"];

        $servidor="localhost:3333";
        $usuario="root";
        $password="";
        $basedatos="f1";

        $conexion=new mysqli($servidor, $usuario, $password, $basedatos);
        if ($conexion -> connect_error) {
            die("La conexión ha fallado: " . $conexion ->connect_error);
        } else {
            print "La conexion ha sido un éxito. ";
        }
// Actualizamos los datos de la escudería
        $sql1 = "UPDATE escuderias SET escuderia = '$escuderia', coche = '$coche', color = '$color', piloto1 = '$piloto1', piloto2 = '$piloto2', director = '$director' WHERE escuderia = '$escuderia'";

        if ($conexion->query($sql1)==TRUE) {
            echo "Los datos se actualizarón correctamente en la base de datos";
        } else {
            echo "Ha ocurrido un Error: " . $conexion->error;
        }

    ?>
    <br><br>
    <a href="admin.php">Volver a admin</a><br><br>
    <a href="index.php">Volver al Inicio</a>
</div>
<!-- Incluimos nuestro pie de página genérico -->
<?php
    include "footer.php";
?>