<?php
    include "header.php";
?>
<div class="altas">
    <?php
        $servidor="localhost:3333";
        $usuario="root";
        $password="";
        $basedatos="f1";

        $conexion=new mysqli($servidor, $usuario, $password, $basedatos);    
        
        $escuderia=$_POST["escuderia"];
        $coche=$_POST["coche"];
        $color=$_POST["color"];
        $piloto1=$_POST["piloto1"];
        $piloto2=$_POST["piloto2"];
        $director=$_POST["director"];


        $sql1="INSERT INTO escuderias(escuderia, coche, color, piloto1, piloto2, director) VALUES ('$escuderia', '$coche', '$color', '$piloto1', '$piloto2', '$director')";
        $sql2="INSERT INTO clasificacion(equipo, puntos) VALUES ('$escuderia', 0)";
        
        if ($conexion->query($sql1)==TRUE) {
            echo "Enhorabuena has registrado un nuevo equipo dentro de la F1, Mucha Suerte $escuderia!!!<br>";
        } else {
            echo "Ha ocurrido un Error: " . $conexion->error;
        }

        if ($conexion->query($sql2)==TRUE) {
            echo "TODO EN ORDEN";
        } else {
            echo "Ha ocurrido un Error: " . $conexion->error;
        }

    ?>
    <br><br>
    <a href="admin.php">Volver a admin</a><br><br>
    <a href="index.php">Volver al Inicio</a>
</div>

<?php
    include "footer.php";
?>